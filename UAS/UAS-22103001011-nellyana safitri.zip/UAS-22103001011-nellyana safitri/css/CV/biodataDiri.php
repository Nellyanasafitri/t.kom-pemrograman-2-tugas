<?php
class BiodataDiri extends CV {
    public $nama = "Nellyana Safitri";
    public $nohp = "0821 5510 4891";
    public $email = "nellyanasafitri2@gmail.com";
    public $jenisKelamin = "Perempuan";
    public $TTL = "Marabahan, 17 Maret 1994";
    
    public function alamat(){
        echo "Lamtoro Gung 2 Blok B No.71";
    }

    function terima ($sd){
        return "{$sd->profil}";
    }
}