<?php
class Education extends CV{
    public $education = "Mts Al-Mujahidin ";
    public $education1 = "Ma Al-Mujahidin";
    public $education4 = "ITSNu Kalimantan";
    
    public function asalsekolah1(){
        echo "Sebangau Kabupaten Pulpis";
    }
    public function asalsekolah2(){
        echo "Jl. Rta. Milono Km 3.5";

    } 
}