<?php
require_once 'css/init.php';
$sd = new BiodataDiri();
$fd = new Profil();
$gh = new Skill();
$jh = new Education();
$rt = new Pengalaman();
$ty = new Cv();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UAS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
 
        <div class="card-one">

            <div class="Profile"></div>

            <div class="Contact-box">
                <h2><?php
                echo $sd->nama;?></h2>
                <div>
                    <div class="text"><?php echo $sd->alamat();?></div>
                </div>
                <div>
                    <div class="text"><?php echo $sd->email;?></div>
                </div>
                <div>
                    <div class="text"><?php echo $sd->nohp;?></div>
                </div>
            <div>
                <div class="text"><?php echo $sd->TTL;?></div>
            </div>
            </div>

            <div class="Personal-box">
                <h2><?php echo $fd->about;?></h2>
                <hr>
                <div>
                    <p><?php echo $fd->profil();?></p>
                </div>
            </div>
            
            <div class="hobbies-box">
                <div class = "logo">
                <h2><?php echo $ty->profil1;?></h2>
                <hr>
                <div>
                    <p><?php echo $gh->skill1;?></p> 
                    <p><?php echo $gh->skill2;?></p>
                    <p><?php echo $gh->skill3;?></p>            
                </div>

                </div>

            </div>
        </div>
        <div class="card-two">
            <div class="group-1">
                <div class="box">
                    <h2><?php echo $ty->profil2;?></h2>
                </div>
                <div class="desc">
                    <p><?php echo $rt->pengamana1;?></p>
                    <div><?php echo $rt->alamat1();?></div>
                    <p><?php echo $rt->pengalaman2;?></p>
                    <div><?php echo $rt->alamat2();?></div>
                </div>
            </div>
            <div class="group-2">
                <div class="box">
                    <h2><?php echo $ty->profil3;?></h2>
                </div>
                <div class="desc">
                    <ul>
                        <li>
                            <div><?php echo $jh->education;?></div>
                            <div><?php echo $jh->asalsekolah1();?></div>
                        </li>
                    </ul>
                    <ul>
                        <li>
                            <div><?php echo $jh->education1;?></div>
                            <div><?php echo $jh->asalsekolah1();?></div>
                        </li>
                    </ul>
                    <ul>
                        <li>
                            <div><?php echo $jh->education4;?></div>
                            <div><?php echo $jh->asalsekolah2();?></div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
