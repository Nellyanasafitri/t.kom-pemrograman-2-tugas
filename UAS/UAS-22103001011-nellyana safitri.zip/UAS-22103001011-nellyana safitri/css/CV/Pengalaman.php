<?php

class Pengalaman extends CV{
    public $pengamana1 = "Admin";
    public $pengalaman2 = "Salescounter";

    public function alamat1(){
        echo "didinas Pendidikan Provinsi Kalimantan Tengah";
    }   
    public function alamat2(){
        echo "Gemilang";
    }

}