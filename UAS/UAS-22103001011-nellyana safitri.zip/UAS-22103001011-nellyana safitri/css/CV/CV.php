<?php

class Cv{
    public $profil = "Biodata Diri"; 
    public $profil1 = "Skill";
    public $profil2 = "Work Experience";
    public $profil3 = "Education";

}
