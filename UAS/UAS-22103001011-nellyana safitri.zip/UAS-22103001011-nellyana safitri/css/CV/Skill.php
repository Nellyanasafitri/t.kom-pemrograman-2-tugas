<?php

class Skill extends CV{
    public $skill1 = "Negotiation Skills";
    public $skill2 = "Verbal Comunication";
    public $skill3 = "Nonverbal Comunication";
    
}