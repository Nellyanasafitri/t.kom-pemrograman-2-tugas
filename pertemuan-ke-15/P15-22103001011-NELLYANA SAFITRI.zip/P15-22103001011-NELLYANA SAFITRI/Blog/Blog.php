<?php

class Blog
{
    public $title = " Title of a longer feantured<br>blog post";
    public $title2 = "Another blog post";
    public $date = "December 23, 2020 by ";
    
    public function paragraph1 ()
    {
        return "Multiple lines of text that form the lede, informing new readers quickly <br>
        and efficiently about what's most interesting in this post's contents <br>" ;
    }
    public function link()
    {
        return "<b> continue reading... </b>";
    }
    public function time (){
        return "Jacob";
    }
    public function information1 (){
        return "This is some additional paragraph placeholder content. It has been written to fill the available space and show how a
         longer snippet if text affects the surrounding content. We'll repeat it often to keep the demonstration flowing, so be on
         the lookout for this exact same string of text.";
    }
    public function information2 (){
        return "Longer quote goes here, maybe with some";
    }   
        public function besar (){
            return " <b> emphasized text </b>";
            }  
            public function info (){
                return "in the middle of it.";
                }  
    public function info3 (){
        return "This is some additional paragraph placeholder content. It has been written to fill the available space and show how a
            longer snippet of text affect the surrounding content. We'll repeat it often to keep the demonstration flowing, so be on
            the lookout for this exact same string of text.";
    }   
}


