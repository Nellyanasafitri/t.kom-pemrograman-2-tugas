<?php

class Profil extends Cv {
    public $about = "Profile";
    public function profil(){
        echo "Nama saya Nellyana Safitri, saya pernah bekerja di Dinas Pendidikan Provinsi sebagai Admin Pengawas Sekolah";
    }
}